import torch
import torch.nn as nn
from torchvision import datasets, transforms
import matplotlib.pyplot as plt
import numpy as np
import random
from PIL import Image

# ==========================================
# 1. 复用之前的模型定义
# ==========================================
class MalariaCNN(nn.Module):
    def __init__(self):
        super(MalariaCNN, self).__init__()
        # 特征提取部分 (卷积层)
        self.features = nn.Sequential(
            # Layer 0
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            
            # Layer 3
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            
            # Layer 6
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        
        # 全连接层分类部分 (此处可视化不需要，但需要模型定义完整)
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 16 * 16, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, 2)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x

# 初始化模型并转移到 M4 芯片的 mps 设备
device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
print(f"当前使用的计算设备: {device}")
model = MalariaCNN().to(device)
model.eval() # 开启评估模式，关闭 Dropout

# ==========================================
# 2. 定义层激活可视化函数
# ==========================================
def visualize_layer_activation(model, layer_index, input_image, device, title):
    # 1. 提取直到特定层的特征子模型
    # 我们根据 nn.Sequential 内部的层索引提取
    # [Conv, ReLU, MaxPool, Conv, ReLU, MaxPool, Conv, ReLU, MaxPool]
    # index: [0, 1, 2, 3, 4, 5, 6, 7, 8]
    sub_model = nn.Sequential(*list(model.features.children())[:layer_index + 1]).to(device)

    # 2. 预处理图像并转移到设备
    input_image = input_image.to(device)

    # 3. 前向传播以获取该层的激活图
    with torch.no_grad():
        activation = sub_model(input_image)

    # 4. 可视化激活图网格
    # activation 的形状是 [Batch, Channel, Height, Width] -> [Channel, Height, Width]
    activation_grid = activation[0].cpu().detach().numpy()
    
    num_channels = activation_grid.shape[0]
    # 计算网格的行和列
    rows = int(np.sqrt(num_channels))
    cols = int(np.ceil(num_channels / rows))
    
    plt.figure(figsize=(cols, rows))
    for i in range(num_channels):
        plt.subplot(rows, cols, i+1)
        # 将每个通道的特征图显示为灰度图
        plt.imshow(activation_grid[i], cmap='gray')
        plt.axis('off')
    
    # 调整标题和布局
    plt.suptitle(f"{title} - Layer Index: {layer_index}", fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

# ==========================================
# 3. 加载示例图像
# ==========================================
# 定义图像预处理，与训练时保持一致
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
])

dataset_path = './malaria_dataset' 
full_dataset = datasets.ImageFolder(root=dataset_path, transform=transform)

# 找到两种不同类别的索引
class_names = full_dataset.classes # ['Parasitized', 'Uninfected']
idx_parasitized = full_dataset.targets.index(full_dataset.class_to_idx['parasitized'])
idx_uninfected = full_dataset.targets.index(full_dataset.class_to_idx['uninfected'])

# 准备感染细胞和未感染细胞的图像张量
image_parasitized, label_parasitized = full_dataset[idx_parasitized]
image_uninfected, label_uninfected = full_dataset[idx_uninfected]

# 给张量添加一个 Batch 维度: [3, 128, 128] -> [1, 3, 128, 128]
image_parasitized = image_parasitized.unsqueeze(0)
image_uninfected = image_uninfected.unsqueeze(0)

# ==========================================
# 4. 进行可视化挑战
# ==========================================
# 我们分别可视化不同深度的卷积层：
# model.features 中的卷积层索引分别为 0, 3, 6

print("正在可视化感染细胞图像的特征提取过程...")
# 浅层：提取纹理和边缘特征
visualize_layer_activation(model, 0, image_parasitized, device, "Parasitized: Shallow Conv (Edges & Texture)")
# 中层：开始聚合特征
visualize_layer_activation(model, 3, image_parasitized, device, "Parasitized: Mid Conv (Compound Patterns)")
# 深层：更高级的抽象特征
visualize_layer_activation(model, 6, image_parasitized, device, "Parasitized: Deep Conv (High-level Semantics)")

print("\n正在可视化未感染细胞图像的特征提取过程...")
visualize_layer_activation(model, 0, image_uninfected, device, "Uninfected: Shallow Conv (Edges & Texture)")
visualize_layer_activation(model, 3, image_uninfected, device, "Uninfected: Mid Conv (Compound Patterns)")
visualize_layer_activation(model, 6, image_uninfected, device, "Uninfected: Deep Conv (High-level Semantics)")