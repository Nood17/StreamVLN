import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, random_split
import matplotlib.pyplot as plt

# ==========================================
# 1. 数据预处理与加载 (保持不变)
# ==========================================
print("正在加载数据...")
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomVerticalFlip(),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
])

dataset_path = './malaria_dataset' 
full_dataset = datasets.ImageFolder(root=dataset_path, transform=transform)

train_size = int(0.8 * len(full_dataset))
val_size = len(full_dataset) - train_size
train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])

batch_size = 128 
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

# ==========================================
# 2. 定义残差块 (Residual Block)
# ==========================================
class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(ResidualBlock, self).__init__()
        # 第一个卷积层：可能会改变通道数或进行下采样(stride>1)
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels) # 配合残差网络常使用的批归一化
        self.relu = nn.ReLU(inplace=True)
        
        # 第二个卷积层：保持尺寸和通道数不变
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        
        # 跳跃连接 (Shortcut)
        self.shortcut = nn.Sequential()
        # 如果输入和输出的尺寸或通道数不一致，需要用 1x1 卷积调整维度，以便后续能够相加
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )

    def forward(self, x):
        identity = self.shortcut(x) # 提取"捷径"信号 x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        
        out += identity # 核心：在这里将 F(x) 与 x 相加！
        out = self.relu(out)
        return out

# ==========================================
# 3. 构建升级版的 ResNet 模型
# ==========================================
class ResNetMalaria(nn.Module):
    def __init__(self):
        super(ResNetMalaria, self).__init__()
        # 初始特征提取
        self.prep = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2)
        )
        
        # 替换为残差块层
        self.layer1 = ResidualBlock(32, 64, stride=2)  # 下采样
        self.layer2 = ResidualBlock(64, 128, stride=2) # 下采样
        
        # 分类器
        # 使用自适应平均池化，这比硬编码全连接层尺寸更灵活、更强大
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(128, 2)

    def forward(self, x):
        x = self.prep(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.pool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x

# 自动分配到你的 MPS 加速器
device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
print(f"\n当前使用的计算设备: {device}")
model = ResNetMalaria().to(device)

# ==========================================
# 4. 训练与验证 (与之前一致)
# ==========================================
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

epochs = 10
train_losses, val_losses = [], []
train_accs, val_accs = [], []

print("开始训练包含残差连接的模型...")
for epoch in range(epochs):
    model.train()
    running_loss, correct_train, total_train = 0.0, 0, 0
    
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total_train += labels.size(0)
        correct_train += (predicted == labels).sum().item()
        
    train_loss = running_loss / len(train_loader)
    train_acc = correct_train / total_train
    train_losses.append(train_loss)
    train_accs.append(train_acc)
    
    model.eval()
    val_loss, correct_val, total_val = 0.0, 0, 0
    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            val_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total_val += labels.size(0)
            correct_val += (predicted == labels).sum().item()
            
    val_loss = val_loss / len(val_loader)
    val_acc = correct_val / total_val
    val_losses.append(val_loss)
    val_accs.append(val_acc)
    
    print(f"Epoch [{epoch+1}/{epochs}] | Train Loss: {train_loss:.4f} Acc: {train_acc:.4f} | Val Loss: {val_loss:.4f} Acc: {val_acc:.4f}")

# 生成图表
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(train_losses, label='Train Loss')
plt.plot(val_losses, label='Validation Loss')
plt.title('ResNet: Training and Validation Loss')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(train_accs, label='Train Accuracy')
plt.plot(val_accs, label='Validation Accuracy')
plt.title('ResNet: Training and Validation Accuracy')
plt.legend()
plt.show()
import torch.nn.functional as F
from sklearn.metrics import roc_curve, auc

# ==========================================
# 5. 保存模型 Checkpoint
# ==========================================
checkpoint_path = 'malaria_resnet_checkpoint.pth'
# 保存模型的状态字典（即训练好的权重）
torch.save(model.state_dict(), checkpoint_path)
print(f"\n模型 Checkpoint 已保存至: {checkpoint_path}")

# ==========================================
# 6. 计算并保存 ROC 曲线
# ==========================================
print("正在生成 ROC 曲线...")
model.eval()
all_labels = []
all_probs = []

with torch.no_grad():
    for images, labels in val_loader:
        images = images.to(device)
        outputs = model(images)
        
        # 使用 Softmax 将输出转换为概率
        probs = F.softmax(outputs, dim=1)
        # 假设类别 1 为正类（你可以根据 dataset.class_to_idx 确认哪一个是目标类）
        class_1_probs = probs[:, 1].cpu().numpy()
        
        all_labels.extend(labels.cpu().numpy())
        all_probs.extend(class_1_probs)

# 计算 FPR, TPR 和 AUC
fpr, tpr, thresholds = roc_curve(all_labels, all_probs)
roc_auc = auc(fpr, tpr)

# 绘制并保存 ROC 曲线
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC)')
plt.legend(loc="lower right")

roc_path = 'roc_curve.png'
plt.savefig(roc_path, dpi=300, bbox_inches='tight') # 高清保存图片
plt.show()
print(f"ROC 曲线已保存至: {roc_path}")